function[ae, ts] = loadDataLoggerAERData(file)

if nargin == 0
    [filename,path,filterindex]=uigetfile({'*.*dat','*.aedat, *.dat'},'Select recorded retina data file');
else
    path='';
    filename=file;
end

fprintf('Reading events capture in DataLogger C# from file %s\n', filename);

f=fopen([path,filename],'r');
line=native2unicode(fgets(f));

while line(1)=='#',
    fprintf('%s',line); % print line using \n for newline, discarding CRLF written by java under windows
    bof=ftell(f); % save end of comment header location
    line=native2unicode(fgets(f)); % gets the line including line ending chars
end

fseek(f,0,'eof');
numEvents=floor((ftell(f)-bof)/8); % 6 or 8 bytes/event
fprintf('There are %d events in file\n',numEvents);

fseek(f,bof,'bof'); % start just after header

% train=int32(zeros(1,2*numEvents)); % allocate horizontal vector to hold output data
ae = uint32(numEvents);
ts = uint32(numEvents);

i = 1;
while ~feof(f)
    line = fgetl(f);
%     train(1:2:i) = uint32(line);
    ts(i) = uint32(line);
    line = fgetl(f);
%     train(2:2:i) = uint32(line);
    ae(i) = uint32(line);
    i = i +1;
end

% ae=uint32(fread(f,numEvents,'uint32',4,'b')); % addr are each 4 bytes (uint32) separated by 4 byte timestamps
% fseek(f,bof+4,'bof'); % timestamps start 4 after bof
% ts=uint32(fread(f,numEvents,'uint32',4,'b')); % ts are 4 bytes (uint32) skipping 4 bytes after each

fclose(f);