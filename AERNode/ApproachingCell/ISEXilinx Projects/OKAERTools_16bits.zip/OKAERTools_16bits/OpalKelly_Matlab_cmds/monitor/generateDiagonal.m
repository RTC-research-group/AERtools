function [ allTs, allAddr ] = generateDiagonal()
%GENERATEDIAGONAL Summary of this function goes here
%   Detailed explanation goes here

allTs = [];
allAddr = [];

us = 10000;
%us = 1;

%addr = 258; %Diagonal principal
addr = 254; %Diagonal secundaria

for i = 1:127
    allTs(end+1,1) = uint32(us * i);
    allAddr(end+1,1) = uint16(addr);
    
    %Diagonal principal
    %addr = addr + 258; 
    %Diagonal secundaria
    addr = addr - 2; 
    addr = addr + 256;
end

end

