function resetMonitor(ok)
%RESETDATALOGGER Reset DataLogger system
addpath('../Matlab_API/okusbfrontpanel');

activatetriggerin(ok, 64, 0);

end

