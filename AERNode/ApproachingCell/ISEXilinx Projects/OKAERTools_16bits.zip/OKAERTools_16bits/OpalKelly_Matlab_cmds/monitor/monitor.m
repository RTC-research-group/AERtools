function [allTs,allAddr] = monitor( ok, bloksize, readLength, numMonitoredEvents)
%function monitor( ok, bloksize,readLength)
%MONITOR Start to monitor events
addpath('../Matlab_API/okusbfrontpanel');

%Se comienza con un reset para vaciar la fifo de salida
resetMonitor(ok);

%newEvent = [];
newEvent = zeros(4);
eventIndex = 1;

absoluteTimestamp = 0;
generalIndex = 1;

while(numMonitoredEvents > 0)%(true)
    
    %readEvents = readfromblockpipeout(ok,160,1024,readLength); %8*1024*1204
    %fprintf('--------------------------------------\n');
    readEvents = readfromblockpipeout(ok,160,bloksize,readLength); %8*1024*1204
    
    %for i = 1:readLength
    for i = 1:length(readEvents)
        
        %Extraer el siguiente evento
        if mod(eventIndex,2) == 0
            newEvent(eventIndex-1) = readEvents(i);
        else
            newEvent(eventIndex+1) = readEvents(i);
        end
        eventIndex = eventIndex + 1;

        if eventIndex == 5
            
            timestamp = uint32((newEvent(1)*256 + newEvent(2)));
            address = uint16((newEvent(3)*256 + newEvent(4)));
            
            %Se descartan los datos nulos
            if (timestamp == 0 && address == 0) || (timestamp == 0 && address ~= 0)
                eventIndex = 1;
                continue;
            end
            
            if (timestamp == 65535)
                absoluteTimestamp = uint32(absoluteTimestamp + 65536);
                
            else
                absoluteTimestamp = absoluteTimestamp + timestamp;
                %fprintf('Timestamp: %d;  Address: %d\n', timestamp, address);
                %fprintf('%d\n', address);
                allAddr(generalIndex,1) = address;
                allTs(generalIndex,1) = absoluteTimestamp;
                
                generalIndex = generalIndex + 1;
                numMonitoredEvents = numMonitoredEvents - 1;
            end
            
            fprintf('Timestamp: %d;  Address: %d\n', timestamp, address);
%             if((timestamp == 0 && address ~= 0) || (timestamp == 65535 && address ~= 0) || (timestamp ~= 65535 && timestamp ~= 0 && address == 0))            
%                 fprintf('ERROR ^ *********************************************************\n');
%                 return
%             end
            
            eventIndex = 1;
        end
    end
%     fprintf('Bytes leidos: %s', num2str(readEvents));
    
end
    allTs = allTs / 100;
end

