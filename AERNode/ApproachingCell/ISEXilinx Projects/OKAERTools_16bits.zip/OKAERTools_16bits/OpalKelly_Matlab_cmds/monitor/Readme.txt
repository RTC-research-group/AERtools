Ejemplo de uso de los comandos del DataLogger:

>> [ok,error] = initializeOpalKellyFPGA('top_logger.bit');
Crea el objeto okFrontPanel y programa la FPGA con el .bit indicado

>> captureLogger(ok);
Commando para la captura de eventos. Se detine la captura por llenado de la memoria o por acci�n del usuario

>> stopLogger(ok);
Commando de stop de Logger o download

>> [allTs, allAddr] = downloadLogger(ok, 4*1024);
Comando para la descarga de eventos de la memoria RAM por USB. El segundo par�metro indica la longitud de lectura.
Este par�metro est� en funci�n de la profundidad de la FIFO de salida. En este caso se usa 4*1024 porque se tiene
una FIFO de 32bits de dato y una capacidad para 1024 datos.

>> resetDataLogger(ok);
Se�al de reset para el circuito

>> closeOpalKellyDevice(ok);
Se cierra la conexi�n USB con la placa y se destruye el objeto creado anteriormente.

>> saveaerdat([allTs, allAddr]);
Guarda los eventos capturados en un fichero que se puede reproducir en el jAER.