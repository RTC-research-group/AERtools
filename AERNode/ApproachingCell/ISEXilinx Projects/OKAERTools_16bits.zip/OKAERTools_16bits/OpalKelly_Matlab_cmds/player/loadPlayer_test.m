function loadPlayer_test( ok, bloksize, allTs, allAddr)
%function downloadLogger( ok, bloksize, readLength )
%DOWNLOADLOGGER Download the events saved in DDR memory in logger stage
addpath('../Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 1, 65535);
updatewireins(ok);

data = 0;
maxSizeData = 1024;
dtTimestamp = 0;
lastTimestamp = 0;
index = 1;

if ~(size(allTs) == size(allAddr))
    disp('allTs and allAddr have not got the same size.');
    return;
end

for i = 1:size(allTs)
    
    timestamp = allTs(i);
    address = allAddr(i);
        
    uint8split = typecast(timestamp, 'uint8');
    data(index) = uint8split(1);
    data(index + 1) = uint8split(2);
    uint8split = typecast(address, 'uint8');
    data(index + 2) = uint8split(1);
    data(index + 3) = uint8split(2);
    
    index = index + 4;
    
    if(index > maxSizeData)
        writetoblockpipein(ok, 128, bloksize, data, maxSizeData); %bloksize=1024; readLength=8*1024*1204
        index = 1;
    end
end
    
%Evento fin de secuencia
data(index) = uint8(hex2dec('FF'));
data(index+1) = uint8(hex2dec('FF'));
data(index+2) = uint8(hex2dec('FF'));
data(index+3) = uint8(hex2dec('FF'));
index = index + 4;

for i = index:maxSizeData
    data(i) = uint8(0);
end

writetoblockpipein(ok, 128, bloksize, data, maxSizeData);

%Remove Load command
setwireinvalue(ok, 0, 8, 65535);
updatewireins(ok);

