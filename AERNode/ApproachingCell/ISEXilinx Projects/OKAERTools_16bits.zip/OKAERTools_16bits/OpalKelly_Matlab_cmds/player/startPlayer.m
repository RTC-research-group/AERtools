function startPlayer( ok )
%STARTPLAYER Start to sequencer the event pre-load in DDR memory

addpath('../Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 2, 65535);
updatewireins(ok);

end

