function loadPlayer( ok, bloksize, allTs, allAddr)
%function downloadLogger( ok, bloksize, readLength )
%DOWNLOADLOGGER Download the events saved in DDR memory in logger stage
addpath('../Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 1, 65535);
updatewireins(ok);

newEvent = zeros(4);
data = 0;
maxSizeData = 1024;
dtTimestamp = 0;
lastTimestamp = 0;
index = 1;

if ~(size(allTs) == size(allAddr))
    disp('allTs and allAddr have not got the same size.');
    return;
end

for i = 1:size(allTs)
    
    timestamp = allTs(i);
    address = allAddr(i);
    
    dtTimestamp = timestamp - lastTimestamp;
    if(dtTimestamp > 65535)
        %Hay desborde de timestamp
        specialEvents = single (dtTimestamp / 65535);
        for j = 1:specialEvents
            data(index) = uint8(hex2dec('FF'));
            data(index+1) = uint8(hex2dec('FF'));
            data(index+2) = uint8(hex2dec('00'));
            data(index+3) = uint8(hex2dec('00'));
            
            index = index + 4;
        end
        
        dtTimestamp = dtTimestamp - specialEvents*65535;
    end
    
    uint8split = typecast(dtTimestamp, 'uint8');
    data(index) = uint8split(1);
    data(index + 1) = uint8split(2);
    uint8split = typecast(address, 'uint8');
    data(index + 2) = uint8split(1);
    data(index + 3) = uint8split(2);
    
    index = index + 4;
    lastTimestamp = allTs(i);
    
    if(index > maxSizeData)
        writetoblockpipein(ok, 128, bloksize, data, maxSizeData); %bloksize=1024; readLength=8*1024*1204
        %data = zeros(8*1024*1024);
        index = 1;
    end
end
    
%Evento fin de secuencia
data(index) = uint8(hex2dec('FF'));
data(index+1) = uint8(hex2dec('FF'));
data(index+2) = uint8(hex2dec('FF'));
data(index+3) = uint8(hex2dec('FF'));
index = index + 4;

for i = index:maxSizeData
    data(i) = uint8(0);
end

writetoblockpipein(ok, 128, bloksize, data, maxSizeData);

%Remove Load command
setwireinvalue(ok, 0, 8, 65535);
updatewireins(ok);

