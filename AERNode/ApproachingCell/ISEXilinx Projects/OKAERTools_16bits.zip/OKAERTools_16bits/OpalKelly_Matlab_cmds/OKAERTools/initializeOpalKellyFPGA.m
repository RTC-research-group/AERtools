%function [ ok, error ] = initializeOpalKellyFPGA(bitFilePath)
function [ ok ] = initializeOpalKellyFPGA()
%InitializeOpalKellyFPGA Connect Opal Kelly board by, and configure PLL 
%                           with default value and load .bit file

%   Detailed explanation goes here


if ~libisloaded('../Matlab_API/okFrontPanel')
    loadlibrary('../Matlab_API/okFrontPanel', '../Matlab_API/okFrontPanelDLL.h');
end

ok.ptr = 0;
ok.serialNum = '';
ok.deviceID = '';
ok.major = 0;
ok.minor = 0;
ok.model = '';

%Contruct an XEM6010 opal kelly object and open the first device.
ok.ptr = calllib('okFrontPanel', 'okFrontPanel_Construct');

addpath('../Matlab_API/okusbfrontpanel');

ok = openbyserial(ok,'');

ok.serialNum = getserialnumber(ok);
ok.deviceID = getdeviceid(ok);
ok.major = getdevicemajorversion(ok);
ok.minor = getdeviceminorversion(ok);
ok.model = getboardmodel(ok);

loaddefaultpllconfiguration(ok);

% error = configurefpga(ok, bitFilePath);
% 
% if(strcmp(error,'ok_NoError'))
%     disp('Opal Kelly and FPGA initialized corrctly!!!!');
% else
%     error('Failed to initialize or program the FPGA');
% end

end

