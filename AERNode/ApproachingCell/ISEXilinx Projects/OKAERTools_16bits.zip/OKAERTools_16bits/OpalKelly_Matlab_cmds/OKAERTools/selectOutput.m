function selectOutput( ok, output )
%CAPTURELOGGER Start capture action in DataLogger
addpath('../Matlab_API/okusbfrontpanel');

switch output
    case 'Merger_Out'
        outputTranslate = hex2dec('0004');
        
    case 'Player_Out'
        outputTranslate = hex2dec('0008');
        
    otherwise 
        outputTranslate = hex2dec('0000');
end

setwireinvalue(ok, 0, outputTranslate, hex2dec('000C'));
updatewireins(ok);

end

