function [allTs_Out, allAddr_Out] = sendCommand( ok, CMD, selInput, allTs_In, allAddr_In )
%CAPTURELOGGER Start capture action in DataLogger
addpath('../Matlab_API/okusbfrontpanel');

%Define a Timer to lunch the background funtions
% TimeBg = timer('StartDelay', 0, 'TasksToExecute', 1);

%Translate CMD
switch CMD
    case 'Merger'
        cmdTranslate = hex2dec('0000');
        mask = hex2dec('FFF0');
        selectInput(ok, 'Nothing');
        selectOutput(ok, 'Merger_Out');
        
    case 'Monitor'
        cmdTranslate = hex2dec('0410');
        mask = hex2dec('0610');
        selectInput(ok, selInput);
        selectOutput(ok, 'Nothing');
        
    case 'Stop_Monitor'
        cmdTranslate = hex2dec('0000');
        mask = hex2dec('0010');        
        
    case 'Log'
        cmdTranslate = hex2dec('0220');
        mask = hex2dec('0660');
        selectInput(ok, selInput);
        selectOutput(ok, 'Nothing');
        
    case 'Stop_Log'
        cmdTranslate = hex2dec('0240');
        mask = hex2dec('0660');
    
    case 'Download_Log'
        cmdTranslate = hex2dec('0260');
        mask = hex2dec('0660');
            
    case 'Load_Data'
        cmdTranslate = hex2dec('0680');
        mask = hex2dec('0780');
        
    case 'Play'
        cmdTranslate = hex2dec('0700');
        mask = hex2dec('0780');
        selectInput(ok, 'Nothing');
        selectOutput(ok, 'Player_Out');
        
    case 'Stop_Play'
        cmdTranslate = hex2dec('0780');
        mask = hex2dec('0780');
        
    case 'Stop_General'
        cmdTranslate = hex2dec('0000');
        mask = hex2dec('FFF0');
        selectInput(ok, 'Nothing');
        selectOutput(ok, 'Nothing');
        
    otherwise %Nothing
        cmdTranslate = hex2dec('0000');
        mask = hex2dec('0000');
end
    
% selectInput(ok, selInput);
% selectOutput(ok, selOutput);
        
setwireinvalue(ok, 0, cmdTranslate, mask);
updatewireins(ok);

%Run background functions
switch CMD
    case 'Monitor'
        [allTs_Out, allAddr_Out] = monitor(ok, 256*1024);
        %[allTs_Out, allAddr_Out] = monitor_test(ok, 32*1024);
        
    case 'Download_Log'
        [allTs_Out, allAddr_Out] = downloadLog(ok);
%         %events = MyModel;
%         allTs = [];
%         allAddr = [];
%         TimeBg.TimerFcn = @(~,~)downloadLog(ok, allTs, allAddr);
%         start(TimeBg);
    
    case 'Load_Data'
        loadPlayer( ok, allTs_In, allAddr_In);
        
    otherwise
        
end
% 
% delete(TimeBg);

end