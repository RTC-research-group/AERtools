function [ allTs, allAddr ] = downloadLog(ok)
%function downloadLogger( ok, bloksize, readLength )
%DOWNLOADLOGGER Download the events saved in DDR memory in logger stage
addpath('../Matlab_API/okusbfrontpanel');

bloksize = 1024;
readLength = 1048576;

% setwireinvalue(ok, 0, hex2dec('0260'), hex2dec('0660'));
% updatewireins(ok);

allTs = [];
allAddr = [];

endRead = false;

absolute_timestamp = 0;

while(~endRead)
    
    readEvents = readfromblockpipeout(ok,160,bloksize,readLength); %bloksize=1024; readLength=8*1024*1204
    
    for i = 1:4:length(readEvents)
        
        %timestamp_vector = zeros(2);
        %address_vector = zeros(2);
        
        try
            timestamp_vector(1) = readEvents(i);
            %timestamp_vector(2) = hex2dec('7F') & readEvents(i+1);
            timestamp_vector(2) = readEvents(i+1);
            
            address_vector(1) = readEvents(i+2);
            address_vector(2) = readEvents(i+3);
            
            t_FF = uint16(timestamp_vector(2))*256 + uint16(timestamp_vector(1));
            a_FF = uint16(address_vector(2))*256 + uint16(address_vector(1));
            
            %Check if end of download
            if (t_FF == 65535) && (a_FF == 65535)
                endRead = true;
                break;
            end
            
            %Check if end of download
            %if time == hex2dec('FFFF') && addr == hex2dec('FFFF')
            %if time == 65535 && addr == 65535
%             if (timestamp_vector(1) == 255 && timestamp_vector(2) == 255 && address_vector(1) == 255 && address_vector(2) == 255)
%                 endRead = true;
%                 break;
%             end
        
            %while (i+5 < length(readEvents) && readEvents(i+2) == readEvents(i+4) && readEvents(i+3) == readEvents(i+5))
            while (readEvents(i+2) == readEvents(i+4) && readEvents(i+3) == readEvents(i+5))
                i = i+2;
            end
            
        catch e
            break;
        end
        
        %addr = ((address_vector(2) & hex2dec('FF')) | (address_vector(1) & hex2dec('FF')));
        %time = ((timestamp_vector(2) & hex2dec('FF')) | (timestamp_vector(1) & hex2dec('FF')));
        addr = uint16(address_vector(2)) * 256 + uint16(address_vector(1));
        time = uint32(uint16(timestamp_vector(2)) * 256 + uint16(timestamp_vector(1)));
                   
        if time == 0 || addr == 0
            continue;
        end
        
        %if time == hex2dec('FFFF')
        if time == 65535
            absolute_timestamp = uint32(absolute_timestamp + 65536);%hex2dec('10000');
            continue;
            
        else
            absolute_timestamp = uint32(absolute_timestamp + time);
        end

        %Save the event and its timestamp
        allTs(end+1,1) = uint32(absolute_timestamp);
        allAddr(end+1,1) = uint16(addr);
        
    end
    
end

%ns to us Logger clock 100Mz -> T 10 ns
allTs = uint32(round(allTs/100));

sendCommand( ok, 'Stop_Log');
end

