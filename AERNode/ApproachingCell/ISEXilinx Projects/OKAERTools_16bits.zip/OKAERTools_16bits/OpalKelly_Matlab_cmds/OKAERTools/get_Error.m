success = 0;
tolerance = 10;

total_samples = size(rpmtestDVS2,1);

for i = 1: total_samples

    v_real = rpmtestencoder(i,2);
    v_estm = rpmtestDVS2(i,2);
    
    if ( v_estm >= (v_real - (v_real * tolerance/100)) &&  v_estm <= (v_real + (v_real * tolerance/100)))
        
        success = success + 1;
    end;
end;

accurate = (success / total_samples) * 100;