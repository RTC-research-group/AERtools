function resetOKAERTolls(ok)
%RESETDATALOGGER Reset DataLogger system
addpath('../Matlab_API/okusbfrontpanel');

sendCommand(ok, 'Stop_General');
activatetriggerin(ok, 64, 0);
%sendCommand(ok, 'Merger');

end

