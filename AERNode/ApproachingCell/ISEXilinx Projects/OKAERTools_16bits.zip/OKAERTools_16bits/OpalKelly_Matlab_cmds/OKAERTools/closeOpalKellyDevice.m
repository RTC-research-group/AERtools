function ret=closeOpalKellyDevice(obj)

%CLOSEOPALKELLYDEVICE  Close an Opal Kelly FrontPanel-enabled device.
%  Close an attached device and free USB.
%
%  ret=CLOSEOPALKELLYDEVICE(OBJ) close the device by obj.
%
calllib('okFrontPanel', 'okFrontPanel_Destruct', obj.ptr);