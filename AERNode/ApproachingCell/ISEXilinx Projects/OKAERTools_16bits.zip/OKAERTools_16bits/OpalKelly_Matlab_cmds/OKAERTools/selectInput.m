function selectInput( ok, input )
%CAPTURELOGGER Start capture action in DataLogger
addpath('../Matlab_API/okusbfrontpanel');

switch input
    case 'Merger_Out'
        inputTranslate = hex2dec('0001');
        
    case 'NodeBoard_Out'
        inputTranslate = hex2dec('0002');
    
    otherwise 
        inputTranslate = hex2dec('0000');
end

setwireinvalue(ok, 0, inputTranslate, hex2dec('0003'));
updatewireins(ok);

end

