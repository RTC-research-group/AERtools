function [ allTs, allAddr ] = downloadLogger( ok, bloksize, readLength )
%function downloadLogger( ok, bloksize, readLength )
%DOWNLOADLOGGER Download the events saved in DDR memory in logger stage
addpath('../Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 2, 65535);
updatewireins(ok);

allTs = [];
allAddr = [];

%newEvent = [];
newEvent = zeros(4);
eventIndex = 1;
numEvent = 0;

endRead = false;

absoluteTimestamp = 0;
index = 0;

while(~endRead)
    
    readEvents = readfromblockpipeout(ok,160,bloksize,readLength); %bloksize=1024; readLength=8*1024*1204
    
%     if(index > length(readEvents))
%         endRead = true;
%     end
    
    for index = 1:length(readEvents)%readLength
        if mod(eventIndex,2) == 0
            newEvent(eventIndex-1) = readEvents(index);
        else
            newEvent(eventIndex+1) = readEvents(index);
        end
        eventIndex = eventIndex + 1;

        if eventIndex == 5
            
            timestamp = uint32((newEvent(1)*256 + newEvent(2)));
            address = uint16((newEvent(3)*256 + newEvent(4)));
            
            %Check if end of download
            if (timestamp == 65535) && (address == 65535)
                endRead = true;
                break;
            end
            
            %The null data is dropped
            if (timestamp == 0 && address == 0) || (timestamp == 0 && address ~= 0)
                eventIndex = 1;
                continue;
            end
            
            %Check if timestamp is overflow
            if (timestamp == 65535)
                absoluteTimestamp = uint32(absoluteTimestamp + 65536);
                eventIndex = 1;
                continue;
            else
                absoluteTimestamp = uint32(absoluteTimestamp + timestamp);
                numEvent = numEvent + 1;
                %fprintf('Timestamp: %d;  Address: %d; NumEvent %d\n', timestamp, address, numEvent);
                %fprintf('%d\n', address);
            end
            
            %Save the event and its timestamp
            allTs(end+1,1) = uint32(absoluteTimestamp);
            allAddr(end+1,1) = uint16((newEvent(3)*256 + newEvent(4)));

            eventIndex = 1;
        end
    end
    
end

%ns to us Logger clock 100Mz -> T 10 ns
allTs = allTs/100;
end

