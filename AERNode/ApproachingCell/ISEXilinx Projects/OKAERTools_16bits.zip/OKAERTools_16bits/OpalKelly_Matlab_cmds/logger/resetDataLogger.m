function resetDataLogger(ok)
%RESETDATALOGGER Reset DataLogger system
addpath('./Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 32768, 65535);
updatewireins(ok);
setwireinvalue(ok, 0, 0, 65535);
updatewireins(ok);


end

