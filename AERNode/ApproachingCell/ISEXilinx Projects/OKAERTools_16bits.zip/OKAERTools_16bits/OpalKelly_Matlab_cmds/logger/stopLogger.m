function stopLogger( ok )
%STOPLOGGER Stop capture logger command
addpath('../Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 4, 65535);
updatewireins(ok);

end

