function captureLogger( ok )
%CAPTURELOGGER Start capture action in DataLogger
addpath('../Matlab_API/okusbfrontpanel');

setwireinvalue(ok, 0, 1, 65535);
updatewireins(ok);

end

